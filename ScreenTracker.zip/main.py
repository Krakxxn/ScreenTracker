import json

# Fichier pour sauvegarder les tâches
DATA_FILE = "tasks.json"

# Charger les tâches depuis le fichier
def load_tasks():
    try:
        with open(DATA_FILE, "r") as file:
            return json.load(file)
    except FileNotFoundError:
        return {"pending": [], "completed": []}

# Sauvegarder les tâches dans le fichier
def save_tasks(tasks):
    with open(DATA_FILE, "w") as file:
        json.dump(tasks, file)

# Afficher les tâches
def display_tasks(tasks):
    print("\n=== Tâches en cours ===")
    for idx, task in enumerate(tasks["pending"], 1):
        print(f"{idx}. {task}")
    print("\n=== Tâches terminées ===")
    for idx, task in enumerate(tasks["completed"], 1):
        print(f"{idx}. {task}")
    print("\n")

# Ajouter une tâche
def add_task(tasks):
    task = input("Entrez la tâche à ajouter : ")
    tasks["pending"].append(task)
    print(f"Tâche ajoutée : {task}")

# Terminer une tâche
def complete_task(tasks):
    display_tasks(tasks)
    idx = int(input("Numéro de la tâche à terminer : ")) - 1
    task = tasks["pending"].pop(idx)
    tasks["completed"].append(task)
    print(f"Tâche terminée : {task}")

# Supprimer une tâche
def delete_task(tasks):
    display_tasks(tasks)
    idx = int(input("Numéro de la tâche à supprimer : ")) - 1
    task = tasks["pending"].pop(idx)
    print(f"Tâche supprimée : {task}")

# Menu principal
def main():
    tasks = load_tasks()
    while True:
        print("\n=== Gestionnaire de Tâches ===")
        print("1. Voir les tâches")
        print("2. Ajouter une tâche")
        print("3. Marquer une tâche comme terminée")
        print("4. Supprimer une tâche")
        print("5. Quitter")
        choice = input("Choisissez une option : ")

        if choice == "1":
            display_tasks(tasks)
        elif choice == "2":
            add_task(tasks)
        elif choice == "3":
            complete_task(tasks)
        elif choice == "4":
            delete_task(tasks)
        elif choice == "5":
            save_tasks(tasks)
            print("À bientôt !")
            break
        else:
            print("Choix invalide, réessayez.")

if __name__ == "__main__":
    main()
